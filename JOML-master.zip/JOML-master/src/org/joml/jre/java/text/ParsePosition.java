package java.text;

public class ParsePosition {}
