package java.text;

public class FieldPosition {}
